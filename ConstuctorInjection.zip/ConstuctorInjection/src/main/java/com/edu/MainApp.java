package com.edu;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {

	public static void main(String[] args) {
		ApplicationContext ap=new ClassPathXmlApplicationContext("spring.xml");
		Employee e1=(Employee) ap.getBean("empobj");
		e1.empdetails();
		Employee e2=(Employee) ap.getBean("empobj1");
		e2.empdetails();
		Employee e3=(Employee) ap.getBean("empobj2");
		e3.empdetails();

	}

}
