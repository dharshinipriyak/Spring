package com.edu;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig
{
	@Bean
public Folder getFold() {
	return new Folder();
	
}
	@Bean
public Files getfile() {
	return new CourseFile();
	
}
}
