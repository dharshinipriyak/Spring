package com.edu;

import org.springframework.beans.factory.annotation.Autowired;

public class Folder 
{
	@Autowired
Files doc;

	public Files getDoc() {
		return doc;
	}

	public void setDoc(Files doc) {
		this.doc = doc;
	}
public void config() {
	System.out.println("School Management Folder");
doc.course();
}
}
