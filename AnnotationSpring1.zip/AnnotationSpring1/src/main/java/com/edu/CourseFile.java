package com.edu;

public class CourseFile implements Files {

	public void course() {
		System.out.println("1.Java FullStack Course");
		System.out.println("2.AWS Course");
		
	}

}
