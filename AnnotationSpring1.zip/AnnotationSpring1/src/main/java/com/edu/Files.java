package com.edu;

public interface Files {

	void course();

}
