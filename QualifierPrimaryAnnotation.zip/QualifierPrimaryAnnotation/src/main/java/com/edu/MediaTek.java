package com.edu;

import org.springframework.stereotype.Component;

@Component
public class MediaTek implements MobileProcessor{

	public void processor() {
		System.out.println("World's most popular Processor");
	}

}
