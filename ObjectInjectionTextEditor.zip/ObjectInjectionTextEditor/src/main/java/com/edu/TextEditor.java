package com.edu;

public class TextEditor 
{
private SpellCheck spellcheck;

public SpellCheck getSpellcheck() {
	return spellcheck;
}

public void setSpellcheck(SpellCheck spellcheck) {
	this.spellcheck = spellcheck;
}
public void texteditorfnct() {
	if(spellcheck!=null)
	{
		spellcheck.spellcheckfnct();
	}
	else
	{
		System.out.println("Spell check is disabled");
	}
}
}
