package com.edu;

public class SpellCheck 
{
public void spellcheckfnct() {
	System.out.println("Spell check is enabled");
}
}
