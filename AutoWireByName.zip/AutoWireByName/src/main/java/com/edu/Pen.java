package com.edu;

public class Pen 
{
public void things()
{
	System.out.println("Pen is there");
}
}
