package com.edu;

public class Purse
{
 private Pen pens;

public Pen getPen() {
	return pens;
}

public void setPen(Pen pen) {
	this.pens = pen;
}
 public void thingsavailable() {
	 if(pens!=null)
	 {
		 pens.things();
	 }
	 else
	 {
		 System.out.println("Pen is not there");
	 }
 }
}
