package com.edu;

import org.springframework.stereotype.Component;

@Component
public class CourseFile implements Files{
	public void course() {
		System.out.println("1.Java FullStack Course");
		System.out.println("2.AWS Course");
		System.out.println("3.Data Analyst");
}
}
