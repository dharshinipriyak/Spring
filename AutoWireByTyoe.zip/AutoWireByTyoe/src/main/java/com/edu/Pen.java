package com.edu;

public class Pen {
	public void things()
	{
		System.out.println("Search in purse");
		System.out.println(" Pen is there !!!");
	}
}
