package com.edu;

public interface MobileProcessor {

	void processor();

}
