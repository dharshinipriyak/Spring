package com.edu;

public class TextEditor
{
private SpellCheck spellcheck;


/**
 * by Name and Type
 * public SpellCheck getSpellcheck() {
	return spellcheck;
}


public void setSpellcheck(SpellCheck spellcheck) {
	this.spellcheck = spellcheck;
}
*/
//By constructor
public TextEditor(SpellCheck spellcheck) {
	super();
	this.spellcheck = spellcheck;
}
public void TextEditorfnct() {
	if(spellcheck!=null)
	{
		spellcheck.spellcheckfnct();
	}
	else
	{
		System.out.println("Spell check is disabled");
	}
}

}
