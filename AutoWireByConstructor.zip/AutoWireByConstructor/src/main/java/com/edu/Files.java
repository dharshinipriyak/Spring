package com.edu;

public class Files 
{
public void SearchFile() 
{
	System.out.println("Files are exist");
	System.out.println("One File is found");
}
}
