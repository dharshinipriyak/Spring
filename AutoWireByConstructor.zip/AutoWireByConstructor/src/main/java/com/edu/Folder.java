package com.edu;

public class Folder 
{
private Files file;

public Folder(Files file) {
	super();
	this.file = file;
}
public void searchFolder() {
	if(file!=null)
	{
	file.SearchFile();
	}
	else
	{
		System.out.println("File is Not Found");
	}
}
}
