package com.edu;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CalcServlet
 */
@WebServlet("/CalcServlet")
public class CalcServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CalcServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter out=response.getWriter();
		double n1=Double.parseDouble(request.getParameter("num1"));
		double n2=Double.parseDouble(request.getParameter("num2"));
		String operation=request.getParameter("button");
		double c=0;
		switch(operation)
		{
		case ("Add"):
			c=n1+n2;
		out.println(" Addition of "+n1+" and "+n2+" is : "+c);
		break;
		case ("Sub"):
			c=n1-n2;
		out.println(" Subraction of "+n1+" and "+n2+" is : "+c);
		break;
		case ("Mul"):
			c=n1*n2;
		out.println(" Multiplication of "+n1+" and "+n2+" is : "+c);
		break;
		case ("Div"):
			if(n2==0)
			{
				out.println("Divide by zero error");
			}
			else
			{
			c=n1/n2;
		out.println(" Division of "+n1+" and "+n2+" is : "+c);
		break;
			}	
		}
	

	/*if(operation.equals("Add"))
		{
			c=n1+n2;
			out.println(" Addition of "+n1+" and "+n2+" is : "+c);
		}
		else if(operation.equals("Sub"))
		{
			c=n1-n2;
			out.println(" Subraction of "+n1+" and "+n2+" is : "+c);
			}
		else if(operation.equals("Mul"))
		{
			c=n1*n2;
			out.println(" Multiplication of "+n1+" and "+n2+" is : "+c);

		}
		else if(operation.equals("Div"))
		{
			c=n1/n2;
			out.println(" Division of "+n1+" and "+n2+" is : "+c);
		} 
		*/
		
	}

}
