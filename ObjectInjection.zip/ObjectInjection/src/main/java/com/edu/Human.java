package com.edu;

public class Human 
{
	//injecting the heart in xml file
private Heart heart;

public Heart getHeart() {
	return heart;
}

public void setHeart(Heart heart) {
	this.heart = heart;
	
}
public void humanfunction() {
	if(heart!=null)
	{
		heart.pump();
	}
	else
	{
		System.out.println("Heart is Not Alive");
	}
}
}
