package com.edu;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class UpdationServlet
 */
@WebServlet("/UpdationServlet")
public class UpdationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
			Integer id=Integer.parseInt(request.getParameter("sid"));
			String sn=request.getParameter("sname");
			String sp=request.getParameter("spass");
			int sa=Integer.parseInt(request.getParameter("sage"));
			float sf=Float.parseFloat(request.getParameter("sfees"));
			try {
				Connection con=DbConnect.getConnection();
				Statement st=con.createStatement();
				String s1="select * from student where sid="+id;
				ResultSet rs=st.executeQuery(s1);
				if(rs.next())
				{
				String up="update student set sname='"+sn+"',spass='"+sp+"',sage="+sa+",sfees="+sf+" where sid="+id;
				int i=st.executeUpdate(up);
				if(i>0) {
					out.println("Record is Updated");
				}
				else
				{
					out.println("Record is not updated");
				}
			}
			
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

