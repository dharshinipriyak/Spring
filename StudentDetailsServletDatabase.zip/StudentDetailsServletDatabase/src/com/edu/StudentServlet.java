package com.edu;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class StudentServlet
 */
@WebServlet("/StudentServlet")
public class StudentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StudentServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		String sn=request.getParameter("sname");
		String sp=request.getParameter("spass");
		int sa=Integer.parseInt(request.getParameter("sage"));
		float sf=Float.parseFloat(request.getParameter("sfees"));
		int si=Integer.parseInt(request.getParameter("sid"));
		try {
			Connection con=DBconnect.getConnection();
			Statement st=con.createStatement();
			String ins="insert into student values("+si+",'"+sn+"','"+sp+"',"+sa+","+sf+")";
			int i=st.executeUpdate(ins);
			if(i>0) {
				out.println("Student Details are Registered Successfully");
			}
			else {
				out.println("Not Registered");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

}
