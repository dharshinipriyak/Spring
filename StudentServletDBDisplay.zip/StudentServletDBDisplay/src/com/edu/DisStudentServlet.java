package com.edu;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DisStudentServlet
 */
@WebServlet("/DisStudentServlet")
public class DisStudentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DisStudentServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		RequestDispatcher rd;
		Integer id=Integer.parseInt(request.getParameter("sid"));
		try
		{
			Connection con=DbConnect.getConnection();
			Statement st=con.createStatement();
			String s1="select * from student where sid="+id;
			ResultSet rs=st.executeQuery(s1);
			out.println("<!DOCTYPE html><head><title>STUDENT RECORD BASED ON ID</title></head>");
			out.println("<body><table border='2'>");
			out.println("<tr><th><SID</th><th>SNAME</th><th>SPASS</th><th>SAGE</th><th>SFEES</th>");
			
			if(rs.next())
			{
				out.println("<tr>");
				out.println("<td>"+rs.getInt(1)+"</td>");
				out.println("<td>"+rs.getString(2)+"</td>");
				out.println("<td>"+rs.getString(3)+"</td>");
				out.println("<td>"+rs.getInt(4)+"</td>");
				out.println("<td>"+rs.getFloat(5)+"</td>");
				out.println("</tr></table>");
			}
			
				else
				{
					out.println("Id "+id+" is Not exist. Please Enter Valid Id");
					rd=request.getRequestDispatcher("user.html");
					rd.include(request, response);
				}
		}
		catch (Exception e) {
		e.printStackTrace();
		}
		
		}
	}
