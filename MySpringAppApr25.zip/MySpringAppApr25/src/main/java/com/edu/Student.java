package com.edu;

public class Student {
    public void display() {
    	System.out.println("My First Spring");
    }
}

