package com.edu;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainProduct {

	public static void main(String[] args) {
	ApplicationContext ac=new ClassPathXmlApplicationContext("spring.xml");
	Product pr=(Product) ac.getBean("productobj");
	pr.displayproduct();
	Product pr1=(Product) ac.getBean("productobj1"); 
	pr1.displayproduct();
	System.out.println("First obj"+pr);
	System.out.println("Second obj"+pr1);
	}

}
