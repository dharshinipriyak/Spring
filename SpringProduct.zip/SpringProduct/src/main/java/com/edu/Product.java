package com.edu;

public class Product
{
	public void displayproduct() {
		int Prod_id=1234;
		String Prod_name="Ferrero rocher";
		double Prod_price=650;
		System.out.println("Product Id\t="+Prod_id+"\nProduct Name\t="+Prod_name+"\nProduct Price\t="+Prod_price);
	}
	public Product() {
	System.out.println("Constructor called");
	}
}
